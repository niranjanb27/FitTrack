const express = require("express");
const bodyParser = require("body-parser");
const db = require("./database.js"); // Import database connection

const app = express();
const PORT = 5000;

// Middleware
app.use(express.json()); // To handle JSON data
app.use(express.urlencoded({ extended: true })); // To handle form data

// Signup Route (POST request)
app.post("/signupform", (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const sql = "INSERT INTO users (email, password) VALUES (?, ?)";
    db.query(sql, [email, password], (err, result) => {
        if (err) {
            console.error("❌ Error inserting data:", err);
            return res.status(500).json({ message: "Database error" });
        }
        console.log("✅ User registered:", result);
        res.status(201).json({ message: "User registered successfully!" });
    });
});

// Start Server
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});
