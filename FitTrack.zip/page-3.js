
let button=document.getElementById('bmi');
button.addEventListener('click',()=>{
    const height=parseInt(document.getElementById('height').value);
    const weight=parseInt(document.getElementById('weight').value);
    const result=document.getElementById('output');
    let height_status=false,weight_status=false;

    if(height ==='' || isNaN(height) || (height <=0)){
        document.getElementById('height_error').innerHTML = 'please provide a valid height';
    }else{
        document.getElementById('height_error').innerHTML='';
        height_status=true;
        }

        if(weight ==='' || isNaN(weight) || (weight <=0)){
        document.getElementById('weight_error').innerHTML = 'please provide a valid weight';
    }else{
        document.getElementById('weight_error').innerHTML='';
        weight_status=true;
        }

    if(height_status && weight_status){
        const bmi=(weight/((height*height)/10000)).toFixed(2);

        if(bmi < 18.6){
            result.innerHTML='You are Under Weight. <br>Your BMI is : '+bmi  ;
            
        }else if(bmi >=18.6 && bmi <24.9){
            result.innerHTML='You are Normal. <br>Your BMI is : ' + bmi;
        }else if(bmi >= 25 && bmi < 29.9){
            result.innerHTML='You are Over Weight. <br>Your BMI is :' + bmi;
        }else{
            result.innerHTML='You are Obese. <br>Your BMI is :' +bmi;
        }
    }else{
        alert('error occured');
        result.innerHTML='';
    }    
    
    
});

let but=document.getElementById('diet');
but.addEventListener('click',()=>{
    const height=parseInt(document.getElementById('height').value);
    const weight=parseInt(document.getElementById('weight').value);
    const result=document.getElementById('out');
    let height_status=false,weight_status=false;

    if(height ==='' || isNaN(height) || (height <=0)){
        document.getElementById('height_error').innerHTML = 'please provide a valid height';
    }else{
        document.getElementById('height_error').innerHTML='';
        height_status=true;
        }

        if(weight ==='' || isNaN(weight) || (weight <=0)){
        document.getElementById('weight_error').innerHTML = 'please provide a valid weight';
    }else{
        document.getElementById('weight_error').innerHTML='';
        weight_status=true;
        }

    if(height_status && weight_status){
        const bmi=(weight/((height*height)/10000)).toFixed(2);

        if(bmi < 18.6){
            result.innerHTML='1] Carbohydrates: Whole grains like oats, quinoa, brown rice, and whole wheat bread provide energy and fiber. <br>2] Proteins: Lean sources such as chicken breast, turkey, fish, tofu, beans, and lentils help build and repair tissues. <br>3] Fats: Healthy fats from avocados, nuts, seeds, and olive oil can boost calorie intake.<br>4] Fruits and Vegetables: Aim for a variety of colorful fruits and vegetables to provide vitamins, minerals, and antioxidants.'  ;
            
        }else if(bmi >=18.6 && bmi <24.9){
            result.innerHTML='1] Carbohydrates: Focus on whole grains, fruits, and vegetables for fiber and essential nutrients.<br>2] Proteins: Include lean meats, poultry, fish, eggs, dairy, legumes, and plant-based protein sources like tofu and tempeh.<br>3] Fats: Choose sources like avocados, nuts, seeds, and olive oil for heart-healthy fats.<br>4] Fruits and Vegetables: Consume a variety of colorful options to maximize nutrient intake and support overall health.';
        }else if(bmi >= 25 && bmi < 29.9){
            result.innerHTML='1] Carbohydrates: Limit refined carbohydrates and focus on whole grains, fruits, and vegetables to manage blood sugar levels and promote satiety.<br>2] Proteins: Prioritize lean sources of protein to support muscle mass while reducing overall calorie intake.<br>3] Fats: Be mindful of portion sizes and choose healthy fats in moderation.<br>4] Fruits and Vegetables: Fill half of your plate with non-starchy vegetables and incorporate fruits as snacks or desserts.' ;
        }else{
            result.innerHTML='1] Carbohydrates: Focus on complex carbohydrates and fiber-rich foods to promote fullness and regulate blood sugar levels.<br>2] Proteins: Choose lean sources of protein and incorporate plant-based protein options to reduce saturated fat intake.<br>3] Fats: Limit intake of saturated and trans fats, and prioritize unsaturated fats from sources like avocados, nuts, and seeds.<br>4] Dairy: Opt for low-fat or non-fat dairy products and control portion sizes to manage calorie intake.' ;
        }
    }else{
        alert('error occured');
        result.innerHTML='';
    }    
    
    
});

let butt=document.getElementById('exercise');
butt.addEventListener('click',()=>{
    const height=parseInt(document.getElementById('height').value);
    const weight=parseInt(document.getElementById('weight').value);
    const result=document.getElementById('exe');
    let height_status=false,weight_status=false;

    if(height ==='' || isNaN(height) || (height <=0)){
        document.getElementById('height_error').innerHTML = 'please provide a valid height';
    }else{
        document.getElementById('height_error').innerHTML='';
        height_status=true;
        }

        if(weight ==='' || isNaN(weight) || (weight <=0)){
        document.getElementById('weight_error').innerHTML = 'please provide a valid weight';
    }else{
        document.getElementById('weight_error').innerHTML='';
        weight_status=true;
        }

    if(height_status && weight_status){
        const bmi=(weight/((height*height)/10000)).toFixed(2);

        if(bmi < 18.6){
            result.innerHTML='*Focus on exercises that promote strength and muscle gain while avoiding excessive cardiovascular activities that could further increase calorie expenditure. <br>*Include strength training exercises using resistance bands, body weight, or light weights to build muscle mass. <br>*Aim for moderate-intensity cardiovascular activities like brisk walking or cycling for overall health, but avoid excessive cardio that could further deplete calorie stores.<br>*Incorporate flexibility exercises like yoga or Pilates to improve mobility and prevent injury.'  ;
            
        }else if(bmi >=18.6 && bmi <24.9){
            result.innerHTML='*Emphasize a balanced exercise routine that includes cardiovascular activities, strength training, and flexibility exercises.<br>*Engage in a variety of cardiovascular exercises such as running, swimming, cycling, or aerobic classes for at least 150 minutes per week.<br>*Incorporate flexibility exercises and stretching routines to improve range of motion and prevent injury.<br>*Include strength training exercises targeting major muscle groups 2-3 times per week with moderate to high intensity and 8-12 repetitions per set.';
        }else if(bmi >= 25 && bmi < 29.9){
            result.innerHTML='*Focus on exercises that promote calorie burning, cardiovascular health, and strength building to support weight loss goals.<br>*Include a combination of moderate to high-intensity cardiovascular exercises like brisk walking, jogging, cycling, or elliptical training for at least 150 minutes per week.<br>*Incorporate strength training exercises to build lean muscle mass and boost metabolism, targeting major muscle groups with 2-3 sessions per week.<br>*Incorporate interval training or circuit training to increase calorie burn and improve cardiovascular fitness.' ;
        }else{
            result.innerHTML='*Prioritize exercises that support weight loss, improve cardiovascular health, and build strength while considering joint health and mobility limitations.<br>*Start with low-impact cardiovascular activities like walking, swimming, or cycling, gradually increasing intensity and duration as fitness improves.<br>*ncorporate strength training exercises using body weight, resistance bands, or light weights to build muscle mass and increase metabolism.<br>*Focus on flexibility exercises and mobility drills to improve range of motion, reduce stiffness, and prevent injury.' ;
        }
    }else{
        alert('error occured');
        result.innerHTML='';
    }    
    
    
});

function changeImage()
{
    var background_image=document.getElementById('bmi');
    background_image.src='peter-conlan-LEgwEaBVGMo-unsplash.jpg';
}