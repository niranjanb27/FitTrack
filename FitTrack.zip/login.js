document.getElementById("submit").addEventListener("click", async function (e) {
    e.preventDefault();

    const email = document.getElementById("em").value;
    const password = document.getElementById("pass").value;

    const response = await fetch("http://localhost:5000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
    });

    const data = await response.json();
    if (response.ok) {
        alert("Login Successful!");
        localStorage.setItem("token", data.token);
    } else {
        alert(data.message);
    }
});
